ArunSundar
PA-1 Network Systems

Make file usage
1.There is a separate make file for client and server in their respective directories
2.Do make build in the directories to the executable file

    
Run instructions
1.In the server directory do make build
2.In the client directory do make build
3. DO ./client <IP> <PORT_NO> 
4. DO ./server <PORT_NO>


References:
1.https://www.cs.rutgers.edu/~pxk/417/notes/socket
s/udp.html
2.https://www.geeksforgeeks.org/udp-server-client-implementation-c/
3.https://www.geeksforgeeks.org for other minor doubts and implementation details


