
ArunSundar
PA- 3
Network Systems
IMPLEMATATION OF HTTP PROXY SERVER 
Make file usage
1.There is a make file for the proxy server in the respective directory
2.Do make build in the directories to the executable file

    
Run instructions
1.In the server directory do make build
2. DO ./proxy <TIMEOUT>


References:
1.https://www.cs.rutgers.edu/~pxk/417/notes/socket
s/udp.html
2.https://www.geeksforgeeks.org/udp-server-client-implementation-c/
3.https://www.geeksforgeeks.org for other minor doubts and implementation details
4.https://www.stackoverflow.com for other minor doubts and implementation details

