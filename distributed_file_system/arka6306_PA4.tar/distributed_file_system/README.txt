
ArunSundar
PA- 4
Network Systems
IMPLEMATATION OF DISTRIBUTED FILE SERVER 

Extra credits:
1.Data encryption 
2.Implement subfolder on DFS 
3.Traffic optimization
Make file usage
1.There is a make file for the both the server and client in the respective directory
2.Do make build in the directories to the executable file

    
Run instructions
1.In the server directory do make build
2. DO ./server.o <portno> 10001 - 10004
3. In the client directory do make build
4. Do ./client.o 

References:
1.https://www.cs.rutgers.edu/~pxk/417/notes/socket
s/udp.html
2.https://www.geeksforgeeks.org/udp-server-client-implementation-c/
3.https://www.geeksforgeeks.org for other minor doubts and implementation details
4.https://www.stackoverflow.com for other minor doubts and implementation details

